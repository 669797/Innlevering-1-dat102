package no.hvl.dat102.adt;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import no.hvl.dat102.kjedet.KjedetKoe;

public abstract class KoeADTTest {
private KoeADT<Integer> koe;
	
	private Integer e0 = 1;
	private Integer e1 = 2;
	private Integer e2 = 3;
	private Integer e3 = 4;
	private Integer e4 = 5;
	
	protected abstract KoeADT<Integer> reset();
	
	@BeforeEach
	void setup() {
		koe = reset();
	}

	@Test
	void testNyKoeErTom() {
		assertTrue(koe.erTom());
	}

	@Test
	void testKoeStruktur() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);

		try {
			assertEquals(e0, koe.foerste());
			assertEquals(e0, koe.utKoe());
			assertEquals(e1, koe.foerste());
			assertEquals(e1, koe.utKoe());
			assertEquals(e2, koe.foerste());
		} catch (Exception e) {
			fail("feilet uventet " + e.getMessage());
		}
	}

	@Test
	void testUtKoe() {
		koe.innKoe(e0);
		assertEquals(1, koe.utKoe());
		assertTrue(koe.erTom());
	}

	@Test
	void testFoerste() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);
		assertEquals(1, koe.foerste());
	}

	@Test
	void testErIkkeTom() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		assertFalse(koe.erTom());
	}
	
	@Test
	void erTom() {
		koe.innKoe(e0);
		koe.utKoe();
		assertTrue(koe.erTom());
	}

	@Test
	void testToString() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		assertEquals("1\n2\n", koe.toString());
	}
}
