package no.hvl.data102.adt;

import no.hvl.data102.Film;
import no.hvl.data102.Sjanger;

public interface FilmarkivADT {
//	hente film med gitt nr fra arkivet
//	@param nr er nummer på film som skal hentes
//	@return film med gitt nr. om nr ikke finnes, returnes null.
	Film finnFilm(int nr);
	
//	legger til ny film
	void leggTilFilm(Film nyfilm);
	
//	sletter film med gitt nr
	boolean slettFilm(int filmnr);
	
//	søker og henter filmer med en gitt delstreng i tittelen
	Film[] sokTittel(String delstreng);
	
//	finner antall filmer med gitt sjanger
	int antall(Sjanger sjanger);
	
//	antall filmer i arkivet
	int antall();
}
