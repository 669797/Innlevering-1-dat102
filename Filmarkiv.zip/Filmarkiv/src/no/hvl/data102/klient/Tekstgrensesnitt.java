package no.hvl.data102.klient;

import java.util.Scanner;

import no.hvl.data102.Film;
import no.hvl.data102.Filmarkiv;
import no.hvl.data102.Sjanger;
import no.hvl.data102.adt.FilmarkivADT;

public class Tekstgrensesnitt {

    public Film lesFilm() {
         Scanner sc = new Scanner(System.in);

         System.out.print("Skriv inn filmnummer: ");
         int filmNr = sc.nextInt();

         System.out.print("Skriv inn navn på produsent: ");
         String produsent = sc.next();

         System.out.print("Skriv inn tittel: ");
         String tittel = sc.next();

         System.out.print("Skriv inn lansering: ");
         int lansering = sc.nextInt();

         System.out.print("Skriv inn Sjanger: ");
         Sjanger sjanger1 = Sjanger.finnSjanger(sc.next().toUpperCase());

         System.out.print("Skriv inn filmselskap: ");
         String filmSelskap = sc.next();
         sc.close();

         Film nyFilm = new Film(filmNr, produsent, tittel, lansering, sjanger1, filmSelskap);

         return nyFilm;
    }

    // vise en film med alle opplysninger på skjerm (husk tekst for sjanger)
    public void visFilm(Film film) {
        System.out.println(film.toString());
    }

    // Skrive ut alle Filmer med en spesiell delstreng i tittelen
    public void skrivUtFilmDelstrengITittel(FilmarkivADT filma, String delstreng) {
        Film[] filmer = filma.sokTittel(delstreng);
        for (int i = 0; i < filmer.length; i++) {
            System.out.println(filmer[i].toString());
        }
    }

    // Skriver ut alle Filmer av en produsent / en gruppe
    public void skrivUtFilmProdusent(FilmarkivADT filma, String delstreng) {
        Film[] filmer = filma.sokTittel(delstreng);
        for (int i = 0; i < filmer.length; i++) {
            System.out.println(filmer[i].getProdusent());
        }
    }
 // Skrive ut en enkel statistikk som inneholder antall Filmer totalt
    // og hvor mange det er i hver sjanger
    public void skrivUtStatistikk(FilmarkivADT filma) {
        System.out.println("Antall Filmer: " + filma.antall());
        System.out.println("Antall Actionfilmer: " + filma.antall(Sjanger.ACTION));
        System.out.println("Antall Dramafilmer: " + filma.antall(Sjanger.DRAMA));
        System.out.println("Antall Historyfilmer: " + filma.antall(Sjanger.HISTORY));
        System.out.println("Antall SCIFIfilmer: " + filma.antall(Sjanger.SCIFI));
    }
    // ... Ev. andre metoder

}