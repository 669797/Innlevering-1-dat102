
package no.hvl.data102.klient;

import no.hvl.data102.Film;
import no.hvl.data102.Filmarkiv;
import no.hvl.data102.Sjanger;
import no.hvl.data102.adt.FilmarkivADT;

public class Meny { 
     private Tekstgrensesnitt tekstgr;
     private FilmarkivADT filmarkiv;
     public final String PRODUSENT1 = "Produsent 1";
     public final String PRODUSENT2 = "Produsent 2";
     public final String FILMSELSKAP = "Filmselskap";


     public Meny(FilmarkivADT filmarkiv){ 
      tekstgr = new Tekstgrensesnitt();
      this.filmarkiv = filmarkiv; 
     } 

     public void start(){ 
         Film film1 = new Film(0, PRODUSENT1, "Batman", 1998, Sjanger.ACTION, FILMSELSKAP);
         Film film2 = new Film(1, PRODUSENT1, "Superman", 2000, Sjanger.ACTION, FILMSELSKAP);
         Film film3 = new Film(2, PRODUSENT2, "Bee movie", 2007, Sjanger.DRAMA, FILMSELSKAP);
         Film film4 = new Film(3, PRODUSENT2, "Star Wars Episode X", 2023, Sjanger.SCIFI, FILMSELSKAP);

         filmarkiv.leggTilFilm(film1);
         filmarkiv.leggTilFilm(film4);
         filmarkiv.leggTilFilm(film2);
         filmarkiv.leggTilFilm(film3);
         Film film5 = tekstgr.lesFilm();
         filmarkiv.leggTilFilm(film5);

         tekstgr.skrivUtFilmDelstrengITittel(filmarkiv, "man");
         tekstgr.skrivUtFilmProdusent(filmarkiv, "Batm");
         tekstgr.skrivUtStatistikk(filmarkiv);
         tekstgr.visFilm(film4);
         tekstgr.visFilm(film5);
         
     } 

    }
