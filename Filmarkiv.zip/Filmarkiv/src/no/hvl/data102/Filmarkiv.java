package no.hvl.data102;

import no.hvl.data102.adt.FilmarkivADT;

public class Filmarkiv implements FilmarkivADT {
	private Film[] filmer;
	private int antall;

	public Filmarkiv(int n) {
		filmer = new Film[n];
		this.antall = 0;
	}

	private void utvid() {
		Film[] nytab = new Film[filmer.length * 2];
		for (int i = 0; i < antall; i++) {
			nytab[i] = filmer[i];
		}
		filmer = nytab;
	}

	private Film[] trimTab(Film[] tab, int n) {
		Film[] nytab = new Film[n];
		int i = 0;
		while (i < n) {
			nytab[i] = tab[i];
			i++;
		}
		return nytab;
	}

	@Override
	public Film finnFilm(int nr) {
		Film film = null;
		int i = 0;
		boolean funnet = false;
		while (!funnet && i < antall) {
			if (filmer[i].getFilmnr() == nr) {
				funnet = true;
				film = filmer[i];
			}
			i++;
		}
		return film;
	}

	@Override
	public void leggTilFilm(Film nyfilm) {
		if (antall < filmer.length) {
			filmer[antall] = nyfilm;
			antall++;
		} else {
			utvid();
			filmer[antall] = nyfilm;
			antall++;
		}
	}

	@Override
	public boolean slettFilm(int filmnr) {
		int i = 0;
		boolean slettet = false;
		while (i < antall && !slettet) {
			if (filmer[i].getFilmnr() == filmnr) {
				filmer[i] = filmer[antall];
				filmer[antall] = null;
				antall--;
				slettet = true;
			}
		}
		return slettet;
	}

	@Override
	public Film[] sokTittel(String delstreng) {
		Film[] tab = new Film[antall];
		int n = 0;
		for (int i = 0; i < antall; i++) {
			if (filmer[i].getTittel().contains(delstreng)) {
				tab[n] = filmer[i];
				n++;
			}
		}
		return trimTab(tab, n);
	}

	@Override
	public int antall(Sjanger sjanger) {
		int n = 0;
		for (int i = 0; i < antall; i++) {
			if (filmer[i].getSjanger() == sjanger) {
				n++;
			}
		}
		return n;
	}

	@Override
	public int antall() {
		return antall;
	}

}
