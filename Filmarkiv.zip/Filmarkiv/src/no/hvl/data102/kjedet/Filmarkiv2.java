package no.hvl.data102.kjedet;

import no.hvl.data102.Film;
import no.hvl.data102.Sjanger;
import no.hvl.data102.adt.FilmarkivADT;

public class Filmarkiv2 implements FilmarkivADT {
	private int antall;
	private LinearNode<Film> start;

	public Filmarkiv2() {
		antall = 0;
		start = null;
	}

	@Override
	public Film finnFilm(int nr) {
		boolean funnet = false;
		LinearNode<Film> node = null;
		LinearNode<Film> aktuell = start;
		int i = 0;
		while (i < antall && !funnet) {
			if (aktuell.getElement().getFilmnr() == nr) {
				funnet = true;
				node = aktuell;
			} else {
				aktuell = aktuell.getNeste();
			}
			i++;
		}
		return node.getElement();
	}

	@Override
	public void leggTilFilm(Film nyfilm) {
		LinearNode<Film> nynode = new LinearNode<Film>(nyfilm);
		nynode.setNeste(start);
		start = nynode;
		antall++;

	}

	@Override
	public boolean slettFilm(int filmnr) {
		boolean fjernet = false;
		if (erTom())
			throw new EmptyCollectionException("film");
		LinearNode<Film> node = finnNode(finnFilm(filmnr));
		if (node != null) {
			Film startEl = start.getElement();
			node.setElement(startEl);
			start = start.getNeste();
			fjernet = true;
			antall--;
		}

		return fjernet;
	}

	private LinearNode<Film> finnNode(Film el) {
		boolean funnet = false;
		LinearNode<Film> node = null;
		LinearNode<Film> aktuell = start;
		for (int soek = 0; soek < antall && !funnet; soek++) {
			if (aktuell.getElement().equals(el)) {
				funnet = true;
				node = aktuell;
			} else {
				aktuell = aktuell.getNeste();
			}
		}
		return node;
	}

	public boolean erTom() {
		return antall == 0;
	}

	@Override
	public Film[] sokTittel(String delstreng) {
		Film[] filmer = new Film[antall];
		int i = 0;
		int n = 0;
		LinearNode<Film> aktuell = start;
		while (aktuell != null && i < antall) {
			if (filmer[i].getTittel().contains(delstreng)) {
				filmer[i] = aktuell.getElement();
				n++;
			}
			aktuell.getNeste();
			i++;
		}
		return trimTab(filmer, n);
	}
	
	private Film[] trimTab(Film[] tab, int n) {
		Film[] nytab = new Film[n];
		int i = 0;
		while (i < n) {
			nytab[i] = tab[i];
			i++;
		}
		return nytab;
	}

	@Override
	public int antall(Sjanger sjanger) {
		int n = 0;
		LinearNode<Film> aktuell = start;
		while (aktuell != null) {
			if (aktuell.getElement().getSjanger() == sjanger) {
				n++;
			}
			aktuell = aktuell.getNeste();
		}
		return n;
	}

	@Override
	public int antall() {
		return antall;
	}

}
