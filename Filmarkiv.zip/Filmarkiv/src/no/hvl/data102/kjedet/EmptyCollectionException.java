package no.hvl.data102.kjedet;

public class EmptyCollectionException extends RuntimeException {
	public EmptyCollectionException(String collection) {
		super(" Denne " + collection + " er tom.");
	}
}
